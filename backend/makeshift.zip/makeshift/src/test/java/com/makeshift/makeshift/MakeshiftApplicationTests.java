package com.makeshift.makeshift;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MakeshiftApplicationTests {

	@Test
	void contextLoads() {
	}

}
